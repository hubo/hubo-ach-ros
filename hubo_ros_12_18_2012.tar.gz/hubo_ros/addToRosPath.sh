export ROS_PACKAGE_PATH=/home/geovana/projects/hubo-ros:$ROS_PACKAGE_PATH
rospack profile
rospack find hubo_ros
